<?php

namespace Guikejia\Eav\Exception;

class InvalidEntityAttributeException extends \LogicException
{

}