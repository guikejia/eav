<?php

namespace Guikejia\Eav\Exception;

class InvalidProductException extends \LogicException
{

}