# component-creator

```
composer create-project hyperf/component-creator
```
